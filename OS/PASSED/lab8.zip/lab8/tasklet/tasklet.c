#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/interrupt.h>

struct tasklet_struct *tasklet;
int dev_id, irq = 1;

void tasklet_function(unsigned long data)
{
  printk(KERN_INFO "tasklet: state: %ld, count: %d, data: %ld\n",
         tasklet->state, tasklet->count, tasklet->data);
  return;
}

static irqreturn_t my_interrupt(int irq, void *dev_id)
{
  tasklet_schedule(tasklet);
  return IRQ_HANDLED;
}

static int __init module_tasklet_init(void)
{
  tasklet = vmalloc(sizeof(struct tasklet_struct));
  tasklet_init(tasklet, tasklet_function, 0);
  if (request_irq(irq, my_interrupt, IRQF_SHARED, "my_interrupt", &dev_id))
    return -1;
  printk(KERN_INFO "module is loaded.\n");
  return 0;
}

static void __exit module_tasklet_exit(void)
{
  tasklet_kill(tasklet);
  vfree(tasklet);
  free_irq(irq, &dev_id);
  printk(KERN_INFO "module is unloaded.\n");
  return;
}

MODULE_LICENSE("GPL v2");
MODULE_AUTHOR("Anisimov Nikita");

module_init(module_tasklet_init);
module_exit(module_tasklet_exit);
