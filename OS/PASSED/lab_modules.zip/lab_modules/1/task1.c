/*
Реализовать загружаемый модуль ядра, который при загрузке записывает в системный
журнал сообщение “Hello world!”, а при выгрузке “Good by”. Модуль должен собираться
при помощи Make-файла.
Загружаемый модуль должен содержать:
● Указание лицензии GPL
● Указание автора

sudo insmod ./task1.ko
lsmod | grep task1
dmesg
sudo rmmod task1
*/

#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>


MODULE_LICENSE("GPL");
MODULE_AUTHOR("Gorokhova Irina");
MODULE_DESCRIPTION("Module Printing Hello & Goodbye Messages");

static int __init my_module_init(void) {
	printk("Hello world!\n");
	return 0;
}

static void __exit my_module_exit(void) {
	printk("Goodbye!\n");
}

module_init(my_module_init);
module_exit(my_module_exit);
